import base64
def reverse(s):
	try:
		return "".join(reversed(s.decode("utf-8")))
	except AttributeError:
		return "".join(reversed(s))

def encode(s):
	enc = base64.b64encode(s.encode("utf-8"))
	return reverse(enc)

def decode(s):
	rev = reverse(s)
	dec = base64.b64decode(rev.encode("utf-8"))
	return dec
