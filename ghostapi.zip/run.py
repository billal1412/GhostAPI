from flask import Flask, request, render_template
import ghost, json, requests, os
app = Flask(__name__)

@app.route("/tokped_valid")
def tokped_valid():
	hp = request.args.get("nohp")
	if hp:
		r = requests.get("https://ostch.herokuapp.com/api/v1/tokped?no="+hp).text
		j = json.loads(r)
		for hi in j["result"]:
			data = '{"status":"success","pesan":"Ditemukan"}'
			return "".join(data)
	else:
		data = '{"status":"failed","pesan":"Silahkan Isi Nomor HP"}'
		return "".join(data)

@app.route("/ghostencode")
def ghostencode():
	get = requests.get("https://cyberghostapi.herokuapp.com/enc?type=ghost&text=test").text
	return render_template("ghostencode.html",hasil=get)

@app.route("/ghostdecode")
def ghostdecode():
	get = requests.get("https://cyberghostapi.herokuapp.com/dec?type=ghost&text===AdzVGd").text
	return render_template("ghostdecode.html",hasil=get)

@app.route("/enc")
def enc():
	type = request.args.get("type")
	teks = request.args.get("text")
	if type == "ghost":
		if request.args.get("text"):
			en = ghost.encode(request.args.get("text"))
#			j["type"] = "ghostcrypt#"
#			j["enc"] = str(en)#
#			j["text"] = str(request.args.get("text"))
			data = '{"text":"%s","enc":"%s","type":"ghostcrypt"}'%(teks,en)
			return "".join(data)
		else:
			data = '{"text":null,"type":"ghostcrypt","msg":"Teks tidak ditemukan, silahkan isi teks"}'
			return "".join(data)

@app.route("/dec")
def dec():
	type = request.args.get("type")
	teks = request.args.get("text")
	if type == "ghost":
		if teks:
			dc = ghost.decode(teks).decode("utf-8")
			data = '{"text":"%s","dec":"%s","type":"ghostcrypt"}'%(teks,dc)
			return "".join(data)
		else:
			data = '{"text":null,"type":"ghostcrypt","msg":"Teks tidak di temukan, silahkan isi teks"}'
			return "".join(data)

@app.route("/spam")
def spam():
	ua = requests.get("https://api.svrsc.xyz/uagen.php").json()["ua"]
	type = request.args.get("type")
	hp = request.args.get("nohp")
	if type == "wa":
		if hp:
			r = requests.get("https://core.ktbs.io/v2/user/registration/otp/"+hp,headers={"User-Agent":ua})
			if r.status_code == 200:
				data = '{"status":200,"msg":"Spam Terkirim ke nomor %s"}'%(hp)
				return "".join(data)
			else:
				data = '{"status":%s,"msg":"Spam tidak terkirim"}'%(r.status_code)
				return "".join(data)
		else:
			data = '{"status":"failed","msg":"Silahkan Isi Nomor HP"}'
			return "".join(data)

@app.route("/tokped")
def tokped():
	get = requests.get("https://cyberghostapi/tokped_valid?nohp=6285797379476").text
	return render_template("tokped.html",hasil=get)

@app.route("/getproxy")
def getproxy():
	r = requests.get("https://api.getproxylist.com/proxy")
	j = json.loads(r.text)
	ip = j["ip"]
	port = j["port"]
	protocol = j["protocol"]
	test = j["lastTested"]
	country = j["country"]
	speed = j["downloadSpeed"]
	data = '{"ip":"%s","port","%s","protocol":"%s","tested":"%s","country":"%s","speed":"%s"}'%(ip,port,protocol,test,country,speed)
	return "".join(data)

@app.route("/spam_wa")
def spam_wa():
	get = requests.get("https://cyberghostapi.herokuapp.com/spam?type=wa&nohp=628977825646").text
	return render_template("spam_wa.html",hasil=get)

@app.route("/freeproxy")
def freeproxy():
	get = requests.get("https://cyberghostapi.herokuapp.com/getproxy").text
	return render_template("freeproxy.html",hasil=get)

@app.errorhandler(404)
def not_found(e):
	return render_template("notfound.html")

@app.route("/",methods=["GET","POST"])
def index():
    if request.method == "GET":
        return render_template("index.html")

@app.route("/about")
def about():
	return render_template("about.html")

if __name__ == '__main__':
	app.run(host="0.0.0.0",port=os.environ.get("PORT"),debug=True)
